<?php

use App\Http\Controllers\AffiliateController;
use App\Http\Controllers\AuthController;
use App\Http\Controllers\DonationController;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Route;

/*
|--------------------------------------------------------------------------
| API Routes
|--------------------------------------------------------------------------
|
| Here is where you can register API routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| is assigned the "api" middleware group. Enjoy building your API!
|
*/

// Route::middleware('auth:sanctum')->get('/user', function (Request $request) {
//     return $request->user();
// });
Route::get('user', function() {
    if (Auth::check()) {
        return response()->json(['user' => Auth::user()], 200);
    } 
    return response(null, 401);
});

// Admin
Route::get('affiliates', [AffiliateController::class, 'index']);
Route::post('affiliates', [AffiliateController::class, 'store']);
Route::delete('affiliates/{id}', [AffiliateController::class, 'delete']);

Route::put('user/password', [AuthController::class, 'updatePassword']);

// Donations
Route::get('donations', 'DonationController@index');
Route::post('donations', 'DonationController@store');

// Referents
Route::resource('referents', 'ReferentController');
Route::put('referents/image/{id}', 'ReferentController@updateImage');


